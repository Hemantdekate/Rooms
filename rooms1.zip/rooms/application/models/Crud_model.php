<?php

class Crud_model extends CI_Model {
    
    
    function __consturct() {
        parent::__construct();
        
    }
   
    public function getProfileValue($userid) {
        $user   = $this->db->dbprefix('users');
        $sql    = "SELECT * FROM $user
    WHERE `user_id`='$userid'";
        $query  = $this->db->query($sql);
        $result = $query->row();
        return $result;
    }
    public function getUserValue($id) {
        $user   = $this->db->dbprefix('users');
        $sql    = "SELECT * FROM $user WHERE `user_id`='$id'";
        $query  = $this->db->query($sql);
        $result = $query->row();
        return $result;
    }
   
    public function UserUpdate($id, $data) {
        $this->db->where('user_id', $id);
        $this->db->update('users', $data);
    }
    public function UpdateTododata($id, $data) {
        $this->db->where('id', $id);
        return $this->db->update('to_do_list', $data);
    }
    public function updatePassword($id, $data) {
        $this->db->where('user_id', $id);
        $this->db->update('users', $data);
    }
   
    
    public function getAllUsers() {
        $user   = $this->db->dbprefix('users');
        $sql    = "SELECT * FROM $user WHERE `status`='ACTIVE'";
        $query  = $this->db->query($sql);
        $result = $query->result();
        return $result;
    }

    
    public function addUserInfo($data) {
        $this->db->insert('users', $data);
    }
    
    public function userTableDelet($id) {
        $this->db->delete('users', array(
            'user_id' => $id
        ));
       
    }
  


    public function getAllRooms() {
        $user   = $this->db->dbprefix('room');
        $sql    = "SELECT * FROM $user ";
        $query  = $this->db->query($sql);
        $result = $query->result();
        return $result;
    }

    public function getMyRooms($id) {
        $user   = $this->db->dbprefix('room');
        $sql    = "SELECT * FROM $user WHERE `user_id`='$id'";
        $query  = $this->db->query($sql);
        $result = $query->result();
        return $result;
    }
     public function addRoomInfo($data) {
        $this->db->insert('room', $data);
    }

      public function getRoomValue($id) {
        $user   = $this->db->dbprefix('room');
        $sql    = "SELECT * FROM $user WHERE `id`='$id'";
        $query  = $this->db->query($sql);
        $result = $query->row();
        return $result;
    }

      public function getlatlongValue($id) {
        $user   = $this->db->dbprefix('room');
        $sql    = "SELECT `longitude`,`latitude`,`address` FROM $user WHERE `id`='$id'";
        $query  = $this->db->query($sql);
        $result = $query->row();
        return $result;
    }
     public function RoomUpdate($id, $data) {
        $this->db->where('id', $id);
        $this->db->update('room', $data);
    }


     public function roomTableDelet($id) {
        $this->db->delete('room', array(
            'id' => $id
        ));
        
    }

    
}
?>