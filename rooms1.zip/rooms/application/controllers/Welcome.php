<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function index()
	{
		$this->load->view('front/index');
	}
	public function about()
	{
		$this->load->view('front/about');
	}
	public function properties()
	{
		$this->load->view('front/properties');
	}
	
	
	public function login()
	{
		$this->load->view('Login_view');
	}
	public function register()
	{
		$this->load->view('front/register');
	}
}
