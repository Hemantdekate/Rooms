<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Crud extends CI_Controller{
    
    function __construct(){
        parent::__construct();
        $this->load->database();
        $this->load->model('crud_model');
        $this->load->model('login_model');
    }
    
    public function index(){
        if ($this->session->userdata('user_login_access') != 1)
            redirect(base_url() . 'login', 'refresh');
        if ($this->session->userdata('user_login_access') == 1)
            $data = array();
        redirect('crud/dashboard');
    }
    /*Dashboard section*/
    public function dashboard(){
        if ($this->session->userdata('user_login_access') != False) {
            $data             = array();
            $userid           = $this->session->userdata('user_login_id');
            $this->load->view('backend/dashboard', $data);
        } else {
            redirect(base_url(), 'refresh');
        }
    }
    /*List all user*/
    public function List_user(){
        if ($this->session->userdata('user_login_access') != False) {
            $data                  = array();
            $data['userlist']      = $this->crud_model->getAllUsers();
            $this->load->view('backend/userlist', $data);
        } else {
            redirect(base_url(), 'refresh');
        }
    }
    /*|||||||||||||| UPDATED |||||||||||||||*/
    public function List_user_updated(){
        if ($this->session->userdata('user_login_access') != False) {
            $data                  = array();
            $data['userlist']      = $this->crud_model->getAllUsers();
            $this->load->view('backend/userlist-updated', $data);
        } else {
            redirect(base_url(), 'refresh');
        }
    }
    /*|||||||||||||| UPDATED |||||||||||||||*/
    
    
    /*Add user Form View*/
    public function Add_User(){
        if ($this->session->userdata('user_login_access') != False) {
            $this->load->view('backend/adduser');
        } else {
            redirect(base_url(), 'refresh');
        }
    }
    # user delect
    public function user_delet(){
        if ($this->session->userdata('user_login_access') != False) {
            $id = $this->input->get('id');
            $this->crud_model->userTableDelet($id);
            if ($this->db->affected_rows()) {
                $profile    = $this->crud_model->getUserValue($id);
                $checkimage = "./assets/img/user/$profile->image";
                if (file_exists($checkimage)) {
                    unlink($checkimage);
                    redirect('crud/List_user');
                }
                /*      $this->crud_model->User_Notes_Delet($id);
                $this->crud_model->User_commentid_Delet($id);*/
                
            } else {
                redirect(base_url(), 'refresh');
            }
        }
    }
    /*user profile*/
    public function View_profile(){
        if ($this->session->userdata('user_login_access') != False) {
            $userid                = base64_decode($this->input->get('U'));
            $data                  = array();
            $data['profile']       = $this->crud_model->getProfileValue($userid);
            $this->load->view('backend/profile', $data);
        } else {
            redirect(base_url(), 'refresh');
        }
    }
 
    
    /*Reset password validation*/
    public function Add_Reset_password(){
        if ($this->session->userdata('user_login_access') != False) {
            $id          = $this->session->userdata('user_login_id');
            $oldpass     = sha1($this->input->post('oldpass'));
            $newpass     = $this->input->post('newpass');
            $confirmpass = $this->input->post('confirmpass');
            $userdata    = $this->crud_model->getUserValue($id);
            if ($userdata->password == $oldpass && $newpass == $confirmpass) {
                $data = array();
                $data = array(
                    'password' => sha1($newpass)
                );
                if (!empty($id)) {
                    $update              = $this->crud_model->updatePassword($id, $data);
                    $inserted            = $this->db->affected_rows();
                    $response['status']  = 'success';
                    $response['message'] = "Successfully Updated Your  password";
                    $this->output->set_output(json_encode($response));
                }
            } else {
                $response['status']  = 'error';
                $response['message'] = "Please enter Valid password";
                $this->output->set_output(json_encode($response));
            }
        } else {
            redirect(base_url(), 'refresh');
        }
    }
   
    /*Select user information By user ID*/
    public function viewUserDataBYID(){
        if ($this->session->userdata('user_login_access') != False) {
            $id                = $this->input->get('id');
            $data['uservalue'] = $this->crud_model->getUserValue($id);
            echo json_encode($data);
        } else {
            redirect(base_url(), 'refresh');
        }
    }
    /*user information validation*/
    public function addUserInfo(){
        if ($this->session->userdata('user_login_access') != False) {
            /*Custom Random password generator*/
            function rand_password($length) {
                $str   = "";
                $chars = "abcdefghijklmanopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
                $size  = strlen($chars);
                for ($i = 0; $i < $length; $i++) {
                    $str .= $chars[rand(0, $size - 1)];
                }
                return $str;
            }
            /*Set password length*/
            $pass_hash = sha1(rand_password(7));
            /*password length 7 & convert to Secure Hash Algorithm 1(SHA1)*/
            /*custom user id generator*/
            $userid    = 'U' . rand(500, 1000);
            /*generate random user ID from 500 to 1000*/
            $username  = $this->input->post('name');
            $email     = $this->input->post('email');
            $contact   = $this->input->post('phone');
            $address   = $this->input->post('address');
            $dob       = $this->input->post('birthday');
            $country   = $this->input->post('country');
            $role      = "user";
            $gender    = $this->input->post('gender');
            $date      = date('Y-m-d');
            $this->load->library('form_validation');
            $this->form_validation->set_error_delimiters();
            // Validating Name Field
            $this->form_validation->set_rules('name', 'Name', 'trim|required|min_length[3]|max_length[60]|xss_clean');
            /*validating email field*/
            $this->form_validation->set_rules('email', 'Email', 'trim|required|min_length[7]|max_length[100]|xss_clean');
            /*Validating address field*/
            $this->form_validation->set_rules('address', 'address', 'trim|required|min_length[5]|max_length[150]|xss_clean');
            /*validating contact field*/
            $this->form_validation->set_rules('contact', 'Contact', 'trim|xss_clean');
            /*validating Date Of Birth field*/
            $this->form_validation->set_rules('dob', 'Date Of Birth', 'trim|xss_clean');
            /*validating country field*/
            $this->form_validation->set_rules('country', 'Country', 'trim|xss_clean');
            /*validating role field*/
            $this->form_validation->set_rules('role', 'Role', 'trim|xss_clean');
            /*validating gender field*/
            $this->form_validation->set_rules('gender', 'Gender', 'trim|xss_clean');
            
            if ($this->form_validation->run() == FALSE) {
                $response['status']  = 'error';
                $response['message'] = validation_errors();
                $this->output->set_output(json_encode($response));
            } else {
                if ($this->login_model->Does_email_exists($email)) {
                    $response['status']  = 'error';
                    $response['message'] = 'Email already exits';
                    $this->output->set_output(json_encode($response));
                } else {
                    if ($_FILES['user_image']['name']) {
                        $file_name     = $_FILES['user_image']['name'];
                        $fileSize      = $_FILES["user_image"]["size"] / 1024;
                        $fileType      = $_FILES["user_image"]["type"];
                        $new_file_name = '';
                        $new_file_name .= $userid;
                        
                        $config = array(
                            'file_name' => $new_file_name,
                            'upload_path' => "./assets/img/user",
                            'allowed_types' => "gif|jpg|png|jpeg",
                            'overwrite' => False,
                            'max_size' => "20240000", // Can be set to particular file size , here it is 2 MB(2048 Kb)
                            'max_height' => "600",
                            'max_width' => "600"
                        );
                        
                        $this->load->library('Upload', $config);
                        $this->upload->initialize($config);
                        if (!$this->upload->do_upload('user_image')) {
                            $response['status']  = 'error';
                            $response['message'] = $this->upload->display_errors();
                            $this->output->set_output(json_encode($response));
                        } else {
                            $path                = $this->upload->data();
                            $img_url             = $path['file_name'];
                            $data                = array();
                            $data                = array(
                                'user_id' => $userid,
                                'name' => $username,
                                'email' => $email,
                                'password' => $pass_hash,
                                'address' => $address,
                                'birthday' => $dob,
                                'image' => $img_url,
                                'phone' => $contact,
                                'gender' => $gender,
                                'status' => 'ACTIVE',
                                'user_type' => $role,
                                'created' => $date
                            );
                            $success             = $this->crud_model->addUserInfo($data);
                            $response['status']  = 'success';
                            $response['message'] = "Successfully Added";
                            $this->output->set_output(json_encode($response));
                            #$this->session->set_flashdata('feedback','Successfully Created');
                        }
                    } else {
                        $data                = array();
                        $data                = array(
                            'user_id' => $userid,
                            'name' => $username,
                            'email' => $email,
                            'password' => $pass_hash,
                            'address' => $address,
                            'dob' => $dob,
                            'contact' => $contact,
                            'gender' => $gender,
                            'country' => $country,
                            'status' => 'ACTIVE',
                            'user_type' => $role,
                            'created_on' => $date
                        );
                        $success             = $this->crud_model->addUserInfo($data);
                        $response['status']  = 'success';
                        $response['message'] = "Successfully Created";
                        $this->output->set_output(json_encode($response));
                        #$this->session->set_flashdata('feedback','Successfully Created');    
                    }
                }
            }
        } else {
            redirect(base_url(), 'refresh');
        }
    }
    /*user information update validation*/
    public function updateValue(){
        if ($this->session->userdata('user_login_access') != False) {
            $id       = $this->input->post('userid');
            $username = $this->input->post('name');
            $email    = $this->input->post('email');
            $contact  = $this->input->post('phone');
            $address  = $this->input->post('address');
            $dob      = $this->input->post('birthday');
            $gender   = $this->input->post('gender');
            $this->load->library('form_validation');
            $this->form_validation->set_error_delimiters();
            // Validating Name Field
            $this->form_validation->set_rules('name', 'Name', 'trim|required|min_length[2]|max_length[60]|xss_clean');
            /*validating email field*/
            $this->form_validation->set_rules('email', 'Email', 'trim|required|min_length[7]|max_length[100]|xss_clean');
            /*Validating address field*/
            $this->form_validation->set_rules('address', 'address', 'trim|required|min_length[5]|max_length[150]|xss_clean');
            /*validating contact field*/
            $this->form_validation->set_rules('contact', 'Contact', 'trim|xss_clean');
            /*validating Date Of Birth field*/
            $this->form_validation->set_rules('dob', 'Date Of Birth', 'trim|xss_clean');
         
            /*validating gender field*/
            $this->form_validation->set_rules('gender', 'Gender', 'trim|xss_clean');
            
            if ($this->form_validation->run() == FALSE) {
                $response['status']  = 'error';
                $response['message'] = validation_errors();
                $this->output->set_output(json_encode($response));
            } else {
                
                    $data                = array();
                    $data                = array(
                        'name' => $username,
                        'email' => $email,
                        'address' => $address,
                        'birthday' => $dob,
                        'phone' => $contact,
                        'gender' => $gender );
                    $success             = $this->crud_model->UserUpdate($id, $data);
                    $response['id']      = $id;
                    $response['data']    = $data;
                    $response['status']  = 'success';
                    $response['message'] = "Successfully Updated";
                    $this->output->set_output(json_encode($response));
                
                
            }
        } else {
            redirect(base_url(), 'refresh');
        }
    }
   
    public function unlinkImage(){
        if ($this->session->userdata('user_login_access') != False) {
            $id       = $this->input->get('UN');
            $imgvalue = $this->crud_model->getSingleProImageById($id);
            if (!empty($imgvalue->id)) {
                unlink("./assets/img/product/$imgvalue->img_url");
                $delet               = $this->crud_model->deelet_Img($id);
                $response['status']  = 'success';
                $response['message'] = "Successfully Deleted";
                $this->output->set_output(json_encode($response));
            }
            
        } else {
            redirect(base_url(), 'refresh');
        }
    }

   
    //Similarly, you can force download other files formats like word doc, pdf files, etc.
    public function Download_image(){
        // Get parameters
        $file     = $this->input->get('image');
        $filepath = "./assets/img/user/" . $file;
        // Process download
        if (file_exists($filepath)) {
            header('Content-Description: File Transfer');
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="' . basename($filepath) . '"');
            header('Expires: 0');
            header('Cache-Control: must-revalidate');
            header('Pragma: public');
            header('Content-Length: ' . filesize($filepath));
            flush(); // Flush system output buffer
            readfile($filepath);
            exit();
        }
    }
   
    
    /*Notification*/
    function set_notification(){
        $data = $_POST["id"];
        $this->load->model('Crud_model');
        $this->Crud_model->set_notifiication($data);
    }

     public function Add_room(){
        if ($this->session->userdata('user_login_access') != False) {
            
            $this->load->view('backend/addroom');
        } else {
            redirect(base_url(), 'refresh');
        }
    }
      public function My_rooms(){
        if ($this->session->userdata('user_login_access') != False) {
            $data['roomlist']      = $this->crud_model->getMyRooms($this->session->userdata('user_login_id'));
            $this->load->view('backend/myrooms',$data);
        } else {
            redirect(base_url(), 'refresh');
        }
    }

     public function Rooms(){
        if ($this->session->userdata('user_login_access') != False) {
            $data                  = array();
            $data['roomlist']      = $this->crud_model->getAllRooms();
            $this->load->view('backend/rooms',$data);
        } else {
            redirect(base_url(), 'refresh');
        }
    }

      public function addimages(){
            $hotel_id      = $this->input->post('hotel_id');
          $lasturl = $this->input->post('lasturl');
                $dataInfo = array();
                $files    = $_FILES;
                $cpt      = count($_FILES['image']['name']);
                for ($i = 0; $i < $cpt; $i++) {
                    $_FILES['image']['name']     = $files['image']['name'][$i];
                    $_FILES['image']['type']     = $files['image']['type'][$i];
                    $_FILES['image']['tmp_name'] = $files['image']['tmp_name'][$i];
                    $_FILES['image']['error']    = $files['image']['error'][$i];
                    $_FILES['image']['size']     = $files['image']['size'][$i];
                    $uploadPath                          = 'uploads/hotels';
                    $config['upload_path']               = $uploadPath;
                    $config['allowed_types']             = 'gif|jpg|png|jpeg';
                    $this->load->library('upload', $config);
                    $this->upload->initialize($config);
                    if ($this->upload->do_upload('image')) {
                        $fileData                    = $this->upload->data();
                        $uploadData[$i]['file_name'] = $fileData['file_name'];
                        $data                       = array();
                        $data                       = array(
                            'hotel_image' => $uploadData[$i]['file_name'],
                            'hotel_id' => $hotel_id
                        );
                        // echo"<pre>"; print_r($_FILES);die;
                        $success     = $this->Hotels_model->insertimage($data);
                   $response['status']  = 'success';
                   $this->session->set_flashdata('message', 'Hotel Image has been  successfully Added');
            
                }
                
            } redirect(site_url($lasturl));  
       
    }


      public function addRoomInfo(){
        if ($this->session->userdata('user_login_access') != False) {
       //  echo"<pre>"; print_r($_FILES);die;
            $rooms  = $this->input->post('rooms');
            $rent     = $this->input->post('rent');
            $advanced   = $this->input->post('advanced');
            $address   = $this->input->post('address');
            $latitude       = $this->input->post('latitude');
            $longitude   = $this->input->post('longitude');
            $pincode     = $this->input->post('pincode');
            $room_type   = $this->input->post('room_type');
            $status   = $this->input->post('status');
            $user_id       = $this->input->post('user_id');

            $this->load->library('form_validation');
            $this->form_validation->set_error_delimiters();
            // Validating Name Field
        
            $this->form_validation->set_rules('address', 'address', 'trim|required|min_length[5]|max_length[150]|xss_clean');
           
            
            if ($this->form_validation->run() == FALSE) {
                $response['status']  = 'error';
                $response['message'] = validation_errors();
                $this->output->set_output(json_encode($response));
            } else {
               
                    if ($_FILES['room_image']['name']) {
                        $file_name     = $_FILES['room_image']['name'];
                        $fileSize      = $_FILES["room_image"]["size"] / 1024;
                        $fileType      = $_FILES["room_image"]["type"];
                        $new_file_name = '';
                        $new_file_name .= "room".$user_id;
                        
                        $config = array(
                            'file_name' => $new_file_name,
                            'upload_path' => "./assets/img/room",
                            'allowed_types' => "gif|jpg|png|jpeg",
                            'overwrite' => False,
                           // 'max_size' => "20240000",
                             // Can be set to particular file size , here it is 2 MB(2048 Kb)
                            // 'max_height' => "600",
                            // 'max_width' => "600"
                        );
                        
                        $this->load->library('Upload', $config);
                        $this->upload->initialize($config);
                        if (!$this->upload->do_upload('room_image')) {
                            $response['status']  = 'error';
                            $response['message'] = $this->upload->display_errors();
                            $this->output->set_output(json_encode($response));
                        } else {
                            $path                = $this->upload->data();
                            $img_url             = $path['file_name'];
                            $data                = array();
                            $data                = array(
                                'rooms' => $rooms,
                                'rent' => $rent,
                                'advanced' => $advanced,
                                'address' => $address,
                                'latitude' => $latitude,
                                'longitude' => $longitude,
                                'pincode' => $pincode,
                                'room_type' => $room_type,
                                'status' => $status,
                                'user_id' => $user_id,
                                'image' => $img_url
                               
                            );
                            $success             = $this->crud_model->addRoomInfo($data);
                            $response['status']  = 'success';
                            $response['message'] = "Successfully Added";
                            $this->output->set_output(json_encode($response));
                            $this->session->set_flashdata('feedback','Successfully Created');
                        }
                    } else {
                        $data                = array();
                        $data                = array(
                             'rooms' => $rooms,
                            'rent' => $rent,
                            'advanced' => $advanced,
                            'address' => $address,
                            'latitude' => $latitude,
                            'longitude' => $longitude,
                            'pincode' => $pincode,
                            'room_type' => $room_type,
                            'status' => $status,
                            'user_id' => $user_id

                        );
                        $success             = $this->crud_model->addRoomInfo($data);
                        $response['status']  = 'success';
                        $response['message'] = "Successfully Created";
                        $this->output->set_output(json_encode($response));
                        #$this->session->set_flashdata('feedback','Successfully Created');    
                    }
                
            }
        } else {
            redirect(base_url(), 'refresh');
        }
    }

     public function viewRoomDataBYID(){
        if ($this->session->userdata('user_login_access') != False) {
            $id                = $this->input->get('id');
            $data['roomvalue'] = $this->crud_model->getRoomValue($id);
            echo json_encode($data);
        } else {
            redirect(base_url(), 'refresh');
        }
    }

    public function updateRoomValue(){
        if ($this->session->userdata('user_login_access') != False) {
             // echo"<pre>"; print_r($_POST);die;
            $rooms  = $this->input->post('rooms');
            $rent     = $this->input->post('rent');
            $advanced   = $this->input->post('advanced');
            $address   = $this->input->post('address');
            $latitude       = $this->input->post('latitude');
            $longitude   = $this->input->post('longitude');
            $pincode     = $this->input->post('pincode');
            $room_type   = $this->input->post('room_type');
            $id   = $this->input->post('roomid');

            $status   = $this->input->post('status');
            // $user_id       = $this->input->post('user_id');
            $this->load->library('form_validation');
            $this->form_validation->set_error_delimiters();
          
            $this->form_validation->set_rules('address', 'address', 'trim|required|min_length[5]|max_length[150]|xss_clean');
          
            
            if ($this->form_validation->run() == FALSE) {
                $response['status']  = 'error';
                $response['message'] = validation_errors();
                $this->output->set_output(json_encode($response));
            } else {
                
                if ($_FILES['room_image']['name']) {
                   $roomvalue = $this->crud_model->getRoomValue($id);
                    $file_name  = $_FILES['room_image']['name'];
                    $fileSize   = $_FILES["room_image"]["size"] / 1024;
                    $fileType   = $_FILES["room_image"]["type"];
                    /*          $new_file_name='';
                    $new_file_name .= $title;*/
                    $checkimage = "./assets/img/room/$roomvalue->image";
                    
                    $config = array(
                        'file_name' => $file_name,
                        'upload_path' => "./assets/img/room",
                        'allowed_types' => "jpg|png|jpeg|svg",
                        'overwrite' => False,
                        // 'max_size' => "13038", // Can be set to particular file size , here it is 220KB(220 Kb)
                        // 'max_height' => "850",
                        // 'max_width' => "850"
                    );
                    
                    $this->load->library('Upload', $config);
                    $this->upload->initialize($config);
                    if (!$this->upload->do_upload('room_image')) {
                        $response['status']  = 'success';
                        $response['message'] = $this->upload->display_errors();
                        $this->output->set_output(json_encode($response));
                    } else {
                        if (file_exists($checkimage)) {
                            unlink($checkimage);
                        }
                        $path                = $this->upload->data();
                        $img_url             = $path['file_name'];
                        $data                = array();
                        $data                = array(
                            'rooms' => $rooms,
                                'rent' => $rent,
                                'advanced' => $advanced,
                                'address' => $address,
                                'latitude' => $latitude,
                                'longitude' => $longitude,
                                'pincode' => $pincode,
                                'room_type' => $room_type,
                                'status' => $status,
                                'image' => $img_url
                        );
                        $success             = $this->crud_model->RoomUpdate($id, $data);
                        $response['status']  = 'success';
                        $response['message'] = "Successfully Updated";
                        $this->output->set_output(json_encode($response));
                        #$this->session->set_flashdata('feedback','Successfully Updated');    
                    }
                } else {
                    $data                = array();
                    $data                = array(
                          'rooms' => $rooms,
                                'rent' => $rent,
                                'advanced' => $advanced,
                                'address' => $address,
                                'latitude' => $latitude,
                                'longitude' => $longitude,
                                'pincode' => $pincode,
                                'room_type' => $room_type,
                                'status' => $status                            
                    );
                    $success             = $this->crud_model->RoomUpdate($id, $data);
                    $response['status']  = 'success';
                    $response['message'] = "Successfully Updated";
                    $this->output->set_output(json_encode($response));
                }
            }
        } else {
            redirect(base_url(), 'refresh');
        }
    }



public function updateOwnValue(){
        if ($this->session->userdata('user_login_access') != False) {
           // echo"<pre>"; print_r($_POST);die;

            $id       = $this->session->userdata('user_login_id');
            $is_owner   = $this->input->post('is_owner');
            $this->load->library('form_validation');
            $this->form_validation->set_error_delimiters();
            // Validating Name Field
           
            $this->form_validation->set_rules('is_owner', 'Owner', 'trim|xss_clean');
            
            if ($this->form_validation->run() == FALSE) {
                $response['status']  = 'error';
                $response['message'] = validation_errors();
                $this->output->set_output(json_encode($response));
            } else {
                
                    $data                = array();
                    $data                = array(
                        'is_owner' => $is_owner 
                    );
                    $success             = $this->crud_model->UserUpdate($id, $data);
                    $response['id']      = $id;
                    $response['data']    = $data;
                    $response['status']  = 'success';
                    $response['message'] = "Successfully Updated";
                    $this->output->set_output(json_encode($response));
                
                
            }
        } else {
            redirect(base_url(), 'refresh');
        }
    }


     public function map() {
         $id                = $this->input->get('id');
         $roomvalue = $this->crud_model->getlatlongValue($id);
       
        $data['coordinate'] = array('lat' => floatval($roomvalue->latitude), 'lng' => floatval($roomvalue->longitude)); 
        $data['address'] = $roomvalue->address;

        $this->load->view('backend/map', $data);
    }

  public function room_delet(){
        if ($this->session->userdata('user_login_access') != False) {
            $id = $this->input->get('id');
            $this->crud_model->roomTableDelet($id);
            if ($this->db->affected_rows()) {
                $profile    = $this->crud_model->getRoomValue($id);
                $checkimage = "./assets/img/room/$profile->image";
                if (file_exists($checkimage)) {
                    unlink($checkimage);
                    redirect('crud/My_rooms');
                }
           
                
            } else {
                redirect(base_url(), 'refresh');
            }
        }
    }
}
/*End crud controller*/
