
 <!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="author" content="Untree.co" />
    <link rel="shortcut icon" href="<?=base_url();?>/assets/front/favicon.png" />

    <meta name="description" content="" />
    <meta name="keywords" content="bootstrap, bootstrap5" />

    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@400;500;600;700&display=swap"
      rel="stylesheet"
    />

    <link rel="stylesheet" href="<?=base_url();?>/assets/front/fonts/icomoon/style.css" />
    <link rel="stylesheet" href="<?=base_url();?>/assets/front/fonts/flaticon/font/flaticon.css" />

    <link rel="stylesheet" href="<?=base_url();?>/assets/front/css/tiny-slider.css" />
    <link rel="stylesheet" href="<?=base_url();?>/assets/front/css/aos.css" />
    <link rel="stylesheet" href="<?=base_url();?>/assets/front/css/style.css" />

    <title>
      Hemant
    </title>
  </head>
  <body>
    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close">
          <span class="icofont-close js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>

    <nav class="site-nav">
      <div class="container">
        <div class="menu-bg-wrap">
          <div class="site-navigation">
            <a href="index.html" class="logo m-0 float-start">Hemant Properties</a>

            <ul
              class="js-clone-nav d-none d-lg-inline-block text-start site-menu float-end"
            >
              <li class="active"><a href="<?=base_url();?>">Home</a></li>
            
              <li><a href="<?=base_url();?>index.php/Welcome/about">About</a></li>
              <li><a href="<?=base_url();?>index.php/Login">Login</a></li>
            </ul>

            <a
              href="#"
              class="burger light me-auto float-end mt-1 site-menu-toggle js-menu-toggle d-inline-block d-lg-none"
              data-toggle="collapse"
              data-target="#main-navbar"
            >
              <span></span>
            </a>
          </div>
        </div>
      </div>
    </nav>
