    <div class="site-footer">
      <div class="container">
        <div class="row mt-5">
          <div class="col-12 text-center">
             <p>Copyright &copy;<script>document.write(new Date().getFullYear());</script>
              <strong>Hemant</strong></p>
          </div>
        </div>
      </div>
      <!-- /.container -->
    </div>
    <!-- /.site-footer -->

    <!-- Preloader -->
    <div id="overlayer"></div>
    <div class="loader">
      <div class="spinner-border" role="status">
        <span class="visually-hidden">Loading...</span>
      </div>
    </div>

    <script src="<?=base_url();?>/assets/front/js/bootstrap.bundle.min.js"></script>
    <script src="<?=base_url();?>/assets/front/js/tiny-slider.js"></script>
    <script src="<?=base_url();?>/assets/front/js/aos.js"></script>
    <script src="<?=base_url();?>/assets/front/js/navbar.js"></script>
    <script src="<?=base_url();?>/assets/front/js/counter.js"></script>
    <script src="<?=base_url();?>/assets/front/js/custom.js"></script>
  </body>
</html>
