<?php $this->load->view('backend/header'); ?>

        <div class="wrapper-page">
            <div class="page-title">
                <h1>Blank page</h1>
            </div>
            <div class="page-content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="panel">
                                <div class="panel-body">
                                    Blank
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> 


<?php $this->load->view('backend/footer'); ?>