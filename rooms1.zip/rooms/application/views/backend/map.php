<!DOCTYPE html>
<html>
<head>
    <title><?php echo $address;?></title>
    <!-- Include necessary scripts and stylesheets for your chosen map library -->
    <!-- For example, for Google Maps API -->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC3-Gr7yC7_PFqYAUuHoiyHSFus64S4yUo"></script>
    <style>
        #map {
            height: 700px;
            width: 100%;
        }
    </style>
</head>
<body>
    <div id="map"></div>
    <script>
        function initMap() {
            var coordinate = <?php echo json_encode($coordinate); ?>;
            var map = new google.maps.Map(document.getElementById('map'), {
                zoom: 17,
                center: coordinate
            });

            // Add marker for the single coordinate
            new google.maps.Marker({
                position: coordinate,
                map: map
            });
        }
    </script>
    <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC3-Gr7yC7_PFqYAUuHoiyHSFus64S4yUo&callback=initMap"></script>
</body>
</html>
