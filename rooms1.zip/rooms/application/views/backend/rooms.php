<?php $this->load->view('backend/header'); ?>
<div class="wrapper-page">

    <div class="page-title">
        <h1><i class="icon-ghost"></i>Rooms</h1>
        <?php echo @$status;  echo @$response;  ?>
    </div>
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="content_wrapper">
                        <div class="table_banner clearfix">
                            <h5 class="table_banner_title">Rooms</h5>
                        </div>
                        <div class="table_body text-left">
                            <table id="example" class="table table-condensed responsive table_custom" cellspacing="0" width="100%">
                                <thead>
                                    <tr>
                                        <th>Action</th>
                                        <th>Created by</th>
                                        <th>Image</th>
                                        <th>Rooms</th>
                                        <th>Address</th>
                                        <th>Room type</th>
                                        <th>Rent</th>
                                        <th>Created</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(!empty($roomlist)){
                                        foreach($roomlist as $value): ?>
                                    <tr>
                                        <td class="action-buttons">
                                              <button type="button" name="submit" class="viewbutton" data-id="<?php echo $value->id; ?>">
                                                    <i class="icon-eye"></i>
                                                </button>
                                                <a  href="<?php echo base_url()?>crud/map?id=<?php echo $value->id; ?>" title="on map" >
                                                    <i class="icon-map"></i>
                                                </a>
                                            <?php if($this->session->userdata('user_type') == 'admin'){ ?>

                                            <button type="button" name="submit" class="userbutton" data-id="<?php echo $value->id; ?>">
                                                    <i class="icon-pencil"></i>
                                                </button>
                                            <a onclick="return confirm('Are you sure to delete this data?')" href="room_delet?id=<?php echo $value->id; ?>" <?php if($value->user_id == $this->session->userdata('user_login_id')){ echo 'hidden'; } ?> >
                                                    <i class="icon-close"></i>
                                                </a>
                                                 
                                            <?php }?>
                                        </td>
                                        <td>
                                            <?php  $uservalue= $this->crud_model->getUserValue($value->user_id);
                                            if(!empty($uservalue)){echo $uservalue->name;}?>
                                        </td>
                                        <td>
                                            <?php if(!empty($value->image)){ ?>
                                            <a href="<?php echo base_url(); ?>assets/img/room/<?php echo $value->image ?>" target="_blank">
                                                <img src="<?php echo base_url(); ?>assets/img/room/<?php echo $value->image ?>" alt="Starter kit"></a>
                                            <?php } else { ?>
                                            <img src="<?php echo base_url(); ?>assets/img/room/default.jpeg" alt="Starter kit">
                                            <?php } ?>
                                        </td>
                                      <td>
                                            <?php echo $value->rooms ?>
                                        </td>
                                        <td>
                                            <?php echo $value->address ?>
                                        </td>
                                         <td>
                                            <?php echo $value->room_type ?>
                                        </td>
                                        <td>
                                            <?php echo $value->rent ?>
                                        </td>
                                        <td>
                                            <?php echo $value->created ?>
                                        </td>
                                      

                                       
                                    </tr>
                                    <?PHP endforeach; }?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
    <span class="flashmessage"></span>
    <div class="modal fade" id="roommodel" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-md" role="document">
        <div class="modal-content">
            <div class="modal-header modal-primary">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="modal-label">Room Info</h4>
            </div>
            <form role="form" action="updateRoomValue" id="RoomValueUpdate" method="post" enctype="multipart/form-data" accept-charset="utf-8">
                <div class="modal-body">
                    <div class="form-group clearfix">
                        <label for="inputMaxLength" class="col-md-3">Rooms</label>
                        <div class="col-md-9">
                            <input type="text" name="rooms" id="rooms" class="form-control" id="inputMaxLength" value='' placeholder="No of Rooms" required>
                        </div>
                    </div>
                    <div class="form-group clearfix">
                        <label for="textareaMaxLength" class="col-md-3">Rent</label>
                        <div class="col-md-3">
                            <input type="number" name="rent" id="rent" class="form-control" value='' placeholder="" required>
                        </div>
                        <label for="textareaMaxLength" class="col-md-3">Advanced</label>
                        <div class="col-md-3">
                            <input type="number" name="advanced" id="advanced" class="form-control" value='' placeholder="" required>
                        </div>
                    </div>
                    <div class="form-group clearfix">
                        <label for="textareaMaxLength" class="col-md-3">Address</label>
                        <div class="col-md-9">
                            <input type="text" name="address" id="address" class="form-control" value='' placeholder="" required>
                        </div>
                    </div>
                     <div class="form-group clearfix">
                        <label for="textareaMaxLength" class="col-md-3">latitude</label>
                        <div class="col-md-3">
                            <input type="text" name="latitude" id="latitude" class="form-control" value='' placeholder="" required>
                        </div>
                        <label for="textareaMaxLength" class="col-md-3">longitude</label>
                        <div class="col-md-3">
                            <input type="text" name="longitude" id="longitude" class="form-control" value='' placeholder="" required>
                        </div>
                    </div>
                    <div class="form-group clearfix">
                        <label for="textareaMaxLength" class="col-md-3">Pincode</label>
                        <div class="col-md-9">
                            <input type="number" name="pincode" id="pincode" class="form-control" value='' placeholder="" required>
                        </div>
                    </div>
                    
                    <div class="form-group clearfix">
                        <label for="textareaMaxLength" class="col-md-3">Room Type</label>
                        <div class="col-md-3">
                            <select name="room_type" id="room_type" class="form-control" style="width: 100%" required>   
                                <option value="single">Single</option>
                                <option value="family">Family</option>
                                <option value="house">House</option>  
 
                            </select>
                        </div>
                 
                        <label for="textareaMaxLength" class="col-md-3">Status</label>
                        <div class="col-md-3">
                            <select name="status" id="status" class="form-control" style="width: 100%" required>               
                                <option value="">Select Here</option>
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>  
                            </select>
                        </div>
                    </div>
                    <div class="form-group clearfix">
                        <div class="col-md-9 col-md-offset-3">
                            <div class="file_prev" style="display: inline-block;"></div>
                            <label for="room_image" class="custom-file-upload">Upload image</label>
                        </div>
                        <div class="col-md-9 col-md-offset-3">
                            <input type="file" class="" id="room_image" name="room_image" aria-describedby="fileHelp">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="col-md-6">
                        <input type="hidden" name="user_id" id="user_id" value=''>
                        <input type="hidden" name="roomid" id="roomid" value=''>

                        <span class="pull-left"></span>
                    </div>
                    <div class="col-md-6">
                        <button type="submit" id="btnSubmit" name="submit" class="btn btn-default btn-custom">Ok</button>
                        <button type="button" class="btn btn-success btn-custom" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
 <div class="modal fade" id="viewmodel" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-md" role="document">
        <div class="modal-content">
            <div class="modal-header modal-primary">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="modal-label">Room Info</h4>
            </div>
            <form role="form" novalidate id="RoomValueview"  accept-charset="utf-8">
                <div class="modal-body">
                    <div class="form-group clearfix">
                        <label for="inputMaxLength" class="col-md-3">Rooms</label>
                        <div class="col-md-9">
                            <input type="text" name="rooms" id="rooms" class="form-control" id="inputMaxLength" value='' placeholder="No of Rooms" readonly>
                        </div>
                    </div>
                    <div class="form-group clearfix">
                        <label for="textareaMaxLength" class="col-md-3">Rent(for each)</label>
                        <div class="col-md-3">
                            <input type="number" name="rent" id="rent" class="form-control" value='' placeholder="" readonly>
                        </div>
                        <label for="textareaMaxLength" class="col-md-3">Advanced</label>
                        <div class="col-md-3">
                            <input type="number" name="advanced" id="advanced" class="form-control" value='' placeholder="" readonly>
                        </div>
                    </div>
                    <div class="form-group clearfix">
                        <label for="textareaMaxLength" class="col-md-3">Address</label>
                        <div class="col-md-9">
                            <input type="text" name="address" id="address" class="form-control" value='' placeholder="" readonly>
                        </div>
                    </div>
                     <div class="form-group clearfix">
                        <label for="textareaMaxLength" class="col-md-3">latitude</label>
                        <div class="col-md-3">
                            <input type="text" name="latitude" id="latitude" class="form-control" value='' placeholder="" readonly>
                        </div>
                        <label for="textareaMaxLength" class="col-md-3">longitude</label>
                        <div class="col-md-3">
                            <input type="text" name="longitude" id="longitude" class="form-control" value='' placeholder="" readonly>
                        </div>
                    </div>
                    <div class="form-group clearfix">
                        <label for="textareaMaxLength" class="col-md-3">Pincode</label>
                        <div class="col-md-9">
                            <input type="number" name="pincode" id="pincode" class="form-control" value='' placeholder="" readonly>
                        </div>
                    </div>
                    <div class="form-group clearfix">
                        <label for="textareaMaxLength" class="col-md-3">Room Type</label>
                        <div class="col-md-3">
                            <input type="text" name="room_type" id="room_type" class="form-control" value='' placeholder="" readonly>
                        </div>
                        <label for="textareaMaxLength" class="col-md-3">Status</label>
                        <div class="col-md-3">
                            <input type="text" name="status" id="status" class="form-control" value='' placeholder="" readonly>
                        </div>
                    </div>
                   
                    <div class="form-group clearfix">
                        <div class="col-md-9 col-md-offset-3">
                            <div class="file_prev" style="display: inline-block;"></div>
                        </div>
                       <!--  <div class="col-md-9 col-md-offset-3">
                            <input type="file" class="" id="room_image" name="room_image" aria-describedby="fileHelp">
                        </div> -->
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="col-md-6">
                      

                        <span class="pull-left"></span>
                    </div>
                    <div class="col-md-6">
                        <button type="button" class="btn btn-success btn-custom" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function() {
        $(".userbutton").click(function(e) {
            e.preventDefault(e);

            // Get the record's ID via attribute  
            var iid = $(this).attr('data-id');
            $('#RoomValueUpdate').trigger("reset");
            $('#roommodel').modal('show');

            $.ajax({
                url: '<?php echo base_url(); ?>crud/viewRoomDataBYID?id=' + iid,
                method: 'GET',
                data: '',
                dataType: 'json',
            }).done(function(response) {
              console.log(response);
                // Populate the form fields with the data returned from server
                var theForm = $('#RoomValueUpdate');

                theForm.find('[name="user_id"]').val(response.roomvalue.user_id).end()
                        .find('[name="roomid"]').val(response.roomvalue.id).end()
                        .find('[name="rooms"]').val(response.roomvalue.rooms).end()
                        .find('[name="rent"]').val(response.roomvalue.rent).end()
                        .find('[name="advanced"]').val(response.roomvalue.advanced).end()
                        .find('[name="address"]').val(response.roomvalue.address).end()
                        .find('[name="latitude"]').val(response.roomvalue.latitude).end()
                        .find('[name="longitude"]').val(response.roomvalue.longitude).end()
                        .find('[name="pincode"]').val(response.roomvalue.pincode).end()
                        .find('[name="status"]').val(response.roomvalue.status).end()
                        .find('[name="room_type"]').val(response.roomvalue.room_type).end();

                var imgSrc = '<?php echo base_url(); ?>' + 'assets/img/room/' + response.roomvalue.image;
                theForm.find('[class="file_prev"]').html('<a href="' + imgSrc + '" target="_blank"><img src="' + imgSrc + '"></a>').end();
            });
        });
    });
</script>

<script type="text/javascript">
    $(document).ready(function() {
        $(".viewbutton").click(function(e) {
            e.preventDefault(e);

            // Get the record's ID via attribute  
            var iid = $(this).attr('data-id');
            $('#RoomValueview').trigger("reset");
            $('#viewmodel').modal('show');

            $.ajax({
                url: '<?php echo base_url(); ?>crud/viewRoomDataBYID?id=' + iid,
                method: 'GET',
                data: '',
                dataType: 'json',
            }).done(function(response) {
              console.log(response);
                // Populate the form fields with the data returned from server
                var theForm = $('#RoomValueview');

                theForm.find('[name="user_id"]').val(response.roomvalue.user_id).end()
                        .find('[name="roomid"]').val(response.roomvalue.id).end()
                        .find('[name="rooms"]').val(response.roomvalue.rooms).end()
                        .find('[name="rent"]').val(response.roomvalue.rent).end()
                        .find('[name="advanced"]').val(response.roomvalue.advanced).end()
                        .find('[name="address"]').val(response.roomvalue.address).end()
                        .find('[name="latitude"]').val(response.roomvalue.latitude).end()
                        .find('[name="longitude"]').val(response.roomvalue.longitude).end()
                        .find('[name="pincode"]').val(response.roomvalue.pincode).end()
                        .find('[name="status"]').val(response.roomvalue.status).end()
                        .find('[name="room_type"]').val(response.roomvalue.room_type).end();

                var imgSrc = '<?php echo base_url(); ?>' + 'assets/img/room/' + response.roomvalue.image;
                theForm.find('[class="file_prev"]').html('<a href="' + imgSrc + '" target="_blank"><img src="' + imgSrc + '"></a>').end();
            });
        });
    });
</script>



<script type="text/javascript">
    $(document).ready(function() {
        $("#btnSubmit").click(function(event) {

            //stop submit the form, we will post it manually.
            event.preventDefault();

            // Get form
            var formval = $('#RoomValueUpdate')[0];

            // Create an FormData object
            var data = new FormData(formval);
            $.ajax({
                type: "POST",
                enctype: 'multipart/form-data',
                url: "<?php echo base_url(); ?>crud/updateRoomValue",
                data: data,
                dataType: 'json',
                processData: false,
                contentType: false,
                cache: false,
                timeout: 600000,
                success: function(response) {
                    if (response.status == 'error') {
                        $(".flashmessage").fadeIn('fast').delay(3000).fadeOut('fast').html(response.message);
                    } else if (response.status == 'success') {
                        $(".flashmessage").fadeIn('fast').delay(8000).fadeOut('fast').html(response.message);
                       
                        location.reload();
                    }
                },
                error: function(response) {
                    
                }
            });

        });

    });
</script>
<?php $this->load->view('backend/footer'); ?>