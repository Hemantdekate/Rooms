<?php $this->load->view('backend/header'); ?>
        <div class="wrapper-page">

            <div class="page-title">
                <h1><i class="icon-home"></i> Add Room</h1>
            </div>
            <div class="page-content">
                <div class="container-fluid">                   
                <div class="row">
                    <div class="col-md-8">
                        <div class="content_wrapper">
                            <div class="table_banner clearfix">
                                <h5 class="table_banner_title">Create Room</h5>
                            </div>
                            <form role="form" action="addRoomInfo"  id="RoomValueUpdate" method="post" enctype="multipart/form-data" accept-charset="utf-8">
                                <div class="p2415">
    								<div class="form-group clearfix">
                                        <label for="inputMaxLength" class="col-md-3">Rooms</label>
                                        <div class="col-md-9">
                                            <input type="number" name="rooms" id="rooms" class="form-control" id="inputMaxLength" value='' placeholder="Noof Rooms Available"  required >
                                        </div>
                                    </div>
                                    <div class="form-group clearfix">
                                        <label for="textareaMaxLength" class="col-md-3">Rent</label>
                                        <div class="col-md-3">
                                            <input type="number" name="rent" id="rent" class="form-control" value='' placeholder="" required>
                                        </div>
                                  
                                        <label for="textareaMaxLength" class="col-md-3">Advanced</label>
                                        <div class="col-md-3">
                                            <input type="number" name="advanced" id="advanced" class="form-control" value='' placeholder="" required>
                                        </div>
                                    </div>
                                    <div class="form-group clearfix">
                                        <label for="textareaMaxLength" class="col-md-3">Address</label>
                                        <div class="col-md-9">
                                            <input type="text" name="address" id="address" class="form-control" value='' placeholder="" required>
                                        </div>
                                    </div>
                                    <div class="form-group clearfix">
                                        <label for="textareaMaxLength" class="col-md-3">latitude</label>
                                        <div class="col-md-3">
                                            <input type="text" name="latitude" id="latitude" class="form-control" value='' placeholder="" required>
                                        </div>
                                  
                                        <label for="textareaMaxLength" class="col-md-3">longitude</label>
                                        <div class="col-md-3">
                                            <input type="text" name="longitude" id="longitude" class="form-control" value='' placeholder="" required>
                                        </div>
                                    </div>
                                    <div class="form-group clearfix">
                                        <label for="textareaMaxLength" class="col-md-3">Pincode</label>
                                        <div class="col-md-9">
                                            <input type="number" name="pincode" id="pincode" class="form-control" value='' placeholder="" required>
                                        </div>
                                    </div>
    								
                                 									
                                    <div class="form-group clearfix">
                                        <label for="textareaMaxLength" class="col-md-3">Room Type</label>
        								<div class="col-md-3">
                                            <select name="room_type" id="room_type" class="form-control" style="width: 100%" required>
                                                <option selected>Select here</option>
                                                <option value="single">Single</option>
                                                <option value="family">Family</option>  
                                                <option value="house">House</option>  

                                            </select>                        
                                        </div>
                                          <label for="textareaMaxLength" class="col-md-3">Status</label>
                                        <div class="col-md-3">
                                            <select name="status" id="status" class="form-control" style="width: 100%" required>
                                                <option value="active">Active</option>
                                                <option value="inactive">Inactive</option>  

                                            </select>                        
                                        </div>
                                    </div>	

                                    <div class="form-group clearfix">
                                        <div class="col-md-9 col-md-offset-3">
                                            <div class="file_prev"></div>
                                            <label for="room_image" class="custom-file-upload">Upload image</label>
                                        </div>
                                        <div class="col-md-9 col-md-offset-3">
                                            <input type="file" class="" id="room_image" name="room_image" aria-describedby="fileHelp" required>
                                        </div>
                                    </div>
                                    <div class="form-group clearfix">
                                        <div class="col-md-9 col-md-offset-3">
                                            <input type="hidden" name="user_id" id="user_id" value='<?php echo $this->session->userdata('user_login_id')?>'>
                                              <input type="hidden" name="roomid" id="roomid" value=''>
                                            <button type="submit" id="btnSubmit" name="submit" class="btn btn-info">Submit</button>
                                            <span class="flashmessage"></span>
                                        </div>
                                    </div>								
                                </div>
    						</form>
                        </div>
                    </div>
                </div>          
            </div>            
        </div>
        </div>	


<?php $this->load->view('backend/footer'); ?>
